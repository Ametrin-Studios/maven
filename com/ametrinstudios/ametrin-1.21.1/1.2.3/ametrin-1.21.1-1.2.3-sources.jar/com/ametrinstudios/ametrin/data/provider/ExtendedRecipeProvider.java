package com.ametrinstudios.ametrin.data.provider;

import com.mojang.logging.LogUtils;
import net.minecraft.advancements.Advancement;
import net.minecraft.advancements.AdvancementHolder;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.data.BlockFamily;
import net.minecraft.data.CachedOutput;
import net.minecraft.data.DataProvider;
import net.minecraft.data.PackOutput;
import net.minecraft.data.recipes.*;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.ItemTags;
import net.minecraft.tags.TagKey;
import net.minecraft.world.flag.FeatureFlagSet;
import net.minecraft.world.flag.FeatureFlags;
import net.minecraft.world.item.DyeColor;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.crafting.Recipe;
import net.minecraft.world.level.ItemLike;
import net.neoforged.neoforge.common.conditions.ICondition;
import net.neoforged.neoforge.common.conditions.WithConditions;
import org.slf4j.Logger;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.CompletableFuture;

@SuppressWarnings("unused")
public abstract class ExtendedRecipeProvider extends RecipeProvider {
    protected static final Logger LOGGER = LogUtils.getLogger();
    protected Set<ResourceLocation> knownRecipes = new HashSet<>();
    protected static final FeatureFlagSet DEFAULT_FEATURE_FLAG_SET = FeatureFlagSet.of(FeatureFlags.VANILLA);

    protected String modId;

    public ExtendedRecipeProvider(String modId, PackOutput output, CompletableFuture<HolderLookup.Provider> registries) {
        super(output, registries);
        this.modId = modId;
    }

    @Override
    protected CompletableFuture<?> run(CachedOutput output, HolderLookup.Provider registries){
        final var list = new ArrayList<CompletableFuture<?>>();
        buildRecipes(new RecipeOutput() {
            @Override
            public void accept(ResourceLocation resourceLocation, Recipe<?> recipe, @Nullable AdvancementHolder advancementHolder, ICondition... conditions) {
                if (!knownRecipes.add(resourceLocation)) { throw new IllegalStateException("Duplicate recipe " + resourceLocation); }

                list.add(DataProvider.saveStable(output, registries, Recipe.CONDITIONAL_CODEC, Optional.of(new WithConditions<>(recipe, conditions)), recipePathProvider.json(resourceLocation)));
                if(advancementHolder != null){
                    list.add(DataProvider.saveStable(output, registries, Advancement.CONDITIONAL_CODEC, Optional.of(new WithConditions<>(advancementHolder.value(), conditions)), advancementPathProvider.json(advancementHolder.id())));
                }
            }

            @Override
            public Advancement.Builder advancement() {
                return Advancement.Builder.recipeAdvancement().parent(RecipeBuilder.ROOT_RECIPE_ADVANCEMENT);
            }
        }, registries);
        return CompletableFuture.allOf(list.toArray(CompletableFuture[]::new));
    }

    @Override
    protected abstract void buildRecipes(RecipeOutput output, HolderLookup.Provider registries);

    protected void stairs(RecipeOutput output, ItemLike stair, ItemLike material, boolean hasStonecutting) {
        stairBuilder(stair, Ingredient.of(material)).unlockedBy(getHasName(material), has(material)).save(output, recipeID(stair, material));
        if (hasStonecutting) {
            stonecutting(output, RecipeCategory.BUILDING_BLOCKS, stair, material, 1);
        }
    }

    protected void stairs(RecipeOutput output, ItemLike stair, ItemLike material, ItemLike... additionalStonecuttingMaterials) {
        stairs(output, stair, material, true);
        for (var mat : additionalStonecuttingMaterials) {
            stonecutting(output, RecipeCategory.BUILDING_BLOCKS, stair, mat, 1);
        }
    }

    protected void slab(RecipeOutput output, ItemLike slab, ItemLike material, boolean hasStonecutting) {
        slabBuilder(RecipeCategory.BUILDING_BLOCKS, slab, Ingredient.of(material)).unlockedBy(getHasName(material), has(material)).save(output, recipeID(slab, material));
        if (hasStonecutting) {
            stonecutting(output, RecipeCategory.BUILDING_BLOCKS, slab, material, 2);
        }
    }

    protected void slab(RecipeOutput output, ItemLike slab, ItemLike material, ItemLike... additionalStonecuttingMaterials) {
        slab(output, slab, material, true);
        for (ItemLike mat : additionalStonecuttingMaterials) {
            stonecutting(output, RecipeCategory.BUILDING_BLOCKS, slab, mat, getItemName(mat).contains("slab") ? 1 : 2);
        }
    }

    protected void wall(RecipeOutput output, ItemLike wall, ItemLike material, boolean hasStonecutting) {
        wallBuilder(RecipeCategory.DECORATIONS, wall, Ingredient.of(material)).unlockedBy(getHasName(material), has(material)).save(output, recipeID(wall, material));
        if (hasStonecutting) {
            stonecutting(output, RecipeCategory.DECORATIONS, wall, material, 1);
        }
    }

    protected void wall(RecipeOutput output, ItemLike wall, ItemLike material, ItemLike... additionalStonecuttingMaterials) {
        wall(output, wall, material, true);
        for (var mat : additionalStonecuttingMaterials) {
            stonecutting(output, RecipeCategory.DECORATIONS, wall, mat, 1);
        }
    }

    protected void button(RecipeOutput output, ItemLike button, ItemLike material, boolean hasStonecutting) {
        buttonBuilder(button, Ingredient.of(material)).unlockedBy(getHasName(material), has(material)).save(output, recipeID(button, material));
        if (hasStonecutting) {
            stonecutting(output, RecipeCategory.REDSTONE, button, material, 1);
        }
    }

    protected void button(RecipeOutput output, ItemLike button, ItemLike material, ItemLike... additionalStonecuttingMaterials) {
        button(output, button, material, true);
        for (var item : additionalStonecuttingMaterials) {
            stonecutting(output, RecipeCategory.REDSTONE, button, item, 1);
        }
    }

    protected void chiseled(RecipeOutput output, ItemLike chiseled, ItemLike material, boolean hasStonecutting) {
        chiseledBuilder(RecipeCategory.BUILDING_BLOCKS, chiseled, Ingredient.of(material)).unlockedBy(getHasName(material), has(material)).save(output, recipeID(chiseled, material));
        if (hasStonecutting) {
            stonecutting(output, RecipeCategory.BUILDING_BLOCKS, chiseled, material, 1);
        }
    }

    protected void fence(RecipeOutput output, ItemLike fence, ItemLike material) {
        fence(output, fence, 3, material, Items.STICK, false);
    }

    protected void netherFence(RecipeOutput output, ItemLike fence, ItemLike material) {
        fence(output, fence, 6, material, Items.NETHER_BRICK, true);
    }

    protected void fence(RecipeOutput output, ItemLike fence, int count, ItemLike material, ItemLike stick, boolean hasStonecutting) {
        shaped(RecipeCategory.DECORATIONS, fence, count).define('W', material).define('#', stick).pattern("W#W").pattern("W#W").unlockedBy(getHasName(material), has(material)).save(output, recipeID(fence, material));
        if (hasStonecutting) {
            stonecutting(output, RecipeCategory.DECORATIONS, fence, material, 1);
        }
    }

    protected void fenceGate(RecipeOutput output, ItemLike fenceGate, ItemLike material) {
        fenceGate(output, fenceGate, material, Items.STICK, false);
    }

    protected void netherFenceGate(RecipeOutput output, ItemLike fenceGate, ItemLike material) {
        fenceGate(output, fenceGate, material, Items.NETHER_BRICK, true);
    }

    protected void fenceGate(RecipeOutput output, ItemLike fenceGate, ItemLike material, ItemLike stick, boolean hasStonecutting) {
        shaped(RecipeCategory.REDSTONE, fenceGate).define('#', stick).define('W', material).pattern("#W#").pattern("#W#").unlockedBy(getHasName(material), has(material)).save(output, recipeID(fenceGate, material));
        if (hasStonecutting) {
            stonecutting(output, RecipeCategory.REDSTONE, fenceGate, material, 1);
        }
    }

    protected void door(RecipeOutput output, ItemLike door, ItemLike material) {
        doorBuilder(door, Ingredient.of(material)).unlockedBy(getHasName(material), has(material)).save(output, recipeID(door, material));
    }

    protected void trapdoor(RecipeOutput output, ItemLike trapdoor, ItemLike material) {
        trapdoorBuilder(trapdoor, Ingredient.of(material)).unlockedBy(getHasName(material), has(material)).save(output, recipeID(trapdoor, material));
    }

    protected void torch(RecipeOutput output, ItemLike torch, ItemLike flammable) {
        shaped(RecipeCategory.DECORATIONS, torch)
                .define('#', flammable)
                .define('|', Items.STICK)
                .pattern("#")
                .pattern("|")
                .unlockedBy(getHasName(flammable), has(flammable))
                .save(output, recipeID(torch, flammable));
    }

    protected void torch(RecipeOutput output, ItemLike torch, TagKey<Item> flammable) {
        shaped(RecipeCategory.DECORATIONS, torch)
                .define('#', flammable)
                .define('|', Items.STICK)
                .pattern("#")
                .pattern("|")
                .unlockedBy(getHasName(flammable), has(flammable))
                .save(output, recipeID(torch, flammable));
    }

    protected void campfire(RecipeOutput output, ItemLike campfire, ItemLike flammable) {
        shaped(RecipeCategory.DECORATIONS, campfire)
                .define('|', Items.STICK)
                .define('#', flammable)
                .define('O', ItemTags.LOGS_THAT_BURN)
                .pattern(" | ")
                .pattern("|#|")
                .pattern("OOO")
                .unlockedBy(getHasName(flammable), has(flammable))
                .save(output, recipeID(campfire, flammable));
    }

    protected void campfire(RecipeOutput output, ItemLike campfire, TagKey<Item> flammable) {
        shaped(RecipeCategory.DECORATIONS, campfire)
                .define('|', Items.STICK)
                .define('#', flammable)
                .define('O', ItemTags.LOGS_THAT_BURN)
                .pattern(" | ")
                .pattern("|#|")
                .pattern("OOO")
                .unlockedBy(getHasName(flammable), has(flammable))
                .save(output, recipeID(campfire, flammable));
    }

    protected void lantern(RecipeOutput output, ItemLike lantern, ItemLike nugget, ItemLike torch) {
        shaped(RecipeCategory.DECORATIONS, lantern)
                .define('|', nugget)
                .define('#', torch)
                .pattern("|||")
                .pattern("|#|")
                .pattern("|||")
                .unlockedBy(getHasName(torch), has(torch))
                .save(output, recipeID(lantern, nugget));
    }

    protected void lantern(RecipeOutput output, ItemLike lantern, TagKey<Item> nugget, ItemLike torch) {
        shaped(RecipeCategory.DECORATIONS, lantern)
                .define('|', nugget)
                .define('#', torch)
                .pattern("|||")
                .pattern("|#|")
                .pattern("|||")
                .unlockedBy(getHasName(torch), has(torch))
                .save(output, recipeID(lantern, nugget));
    }

    protected void tools(RecipeOutput output, ItemLike sword, ItemLike axe, ItemLike pickaxe, ItemLike shovel, ItemLike hoe, ItemLike material) {
        sword(output, sword, material);
        axe(output, axe, material);
        pickaxe(output, pickaxe, material);
        shovel(output, shovel, material);
        hoe(output, hoe, material);
    }

    protected void tools(RecipeOutput output, ItemLike sword, ItemLike axe, ItemLike pickaxe, ItemLike shovel, ItemLike hoe, TagKey<Item> material) {
        sword(output, sword, material);
        axe(output, axe, material);
        pickaxe(output, pickaxe, material);
        shovel(output, shovel, material);
        hoe(output, hoe, material);
    }

    protected void sword(RecipeOutput output, ItemLike sword, ItemLike material) {
        shaped(RecipeCategory.COMBAT, sword)
                .define('#', material)
                .define('|', Items.STICK)
                .pattern("#")
                .pattern("#")
                .pattern("|")
                .unlockedBy(getHasName(material), has(material))
                .save(output, recipeID(sword, material));
    }

    protected void sword(RecipeOutput output, ItemLike sword, TagKey<Item> material) {
        shaped(RecipeCategory.COMBAT, sword)
                .define('#', material)
                .define('|', Items.STICK)
                .pattern("#")
                .pattern("#")
                .pattern("|")
                .unlockedBy(getHasName(material), has(material))
                .save(output, recipeID(sword, material));
    }

    protected void axe(RecipeOutput output, ItemLike axe, ItemLike material) {
        shaped(RecipeCategory.TOOLS, axe)
                .define('#', material)
                .define('|', Items.STICK)
                .pattern("##")
                .pattern("#|")
                .pattern(" |")
                .unlockedBy(getHasName(material), has(material))
                .save(output, recipeID(axe, material));
    }

    protected void axe(RecipeOutput output, ItemLike axe, TagKey<Item> material) {
        shaped(RecipeCategory.TOOLS, axe)
                .define('#', material)
                .define('|', Items.STICK)
                .pattern("##")
                .pattern("#|")
                .pattern(" |")
                .unlockedBy(getHasName(material), has(material))
                .save(output, recipeID(axe, material));
    }

    protected void pickaxe(RecipeOutput output, ItemLike pickaxe, ItemLike material) {
        shaped(RecipeCategory.TOOLS, pickaxe)
                .define('#', material)
                .define('|', Items.STICK)
                .pattern("###")
                .pattern(" | ")
                .pattern(" | ")
                .unlockedBy(getHasName(material), has(material))
                .save(output, recipeID(pickaxe, material));
    }

    protected void pickaxe(RecipeOutput output, ItemLike pickaxe, TagKey<Item> material) {
        shaped(RecipeCategory.TOOLS, pickaxe)
                .define('#', material)
                .define('|', Items.STICK)
                .pattern("###")
                .pattern(" | ")
                .pattern(" | ")
                .unlockedBy(getHasName(material), has(material))
                .save(output, recipeID(pickaxe, material));
    }

    protected void shovel(RecipeOutput output, ItemLike shovel, ItemLike material) {
        shaped(RecipeCategory.TOOLS, shovel)
                .define('#', material)
                .define('|', Items.STICK)
                .pattern("#")
                .pattern("|")
                .pattern("|")
                .unlockedBy(getHasName(material), has(material))
                .save(output, recipeID(shovel, material));
    }

    protected void shovel(RecipeOutput output, ItemLike shovel, TagKey<Item> material) {
        shaped(RecipeCategory.TOOLS, shovel)
                .define('#', material)
                .define('|', Items.STICK)
                .pattern("#")
                .pattern("|")
                .pattern("|")
                .unlockedBy(getHasName(material), has(material))
                .save(output, recipeID(shovel, material));
    }

    protected void hoe(RecipeOutput output, ItemLike hoe, ItemLike material) {
        shaped(RecipeCategory.TOOLS, hoe)
                .define('#', material)
                .define('|', Items.STICK)
                .pattern("##")
                .pattern("| ")
                .pattern("| ")
                .unlockedBy(getHasName(material), has(material))
                .save(output, recipeID(hoe, material));
    }

    protected void hoe(RecipeOutput output, ItemLike hoe, TagKey<Item> material) {
        shaped(RecipeCategory.TOOLS, hoe)
                .define('#', material)
                .define('|', Items.STICK)
                .pattern("##")
                .pattern("| ")
                .pattern("| ")
                .unlockedBy(getHasName(material), has(material))
                .save(output, recipeID(hoe, material));
    }

    protected void armor(RecipeOutput output, ItemLike helmet, ItemLike chestplate, ItemLike leggings, ItemLike boots, ItemLike material) {
        helmet(output, helmet, material);
        chestplate(output, chestplate, material);
        leggings(output, leggings, material);
        boots(output, boots, material);
    }

    protected void armor(RecipeOutput output, ItemLike helmet, ItemLike chestplate, ItemLike leggings, ItemLike boots, TagKey<Item> material) {
        helmet(output, helmet, material);
        chestplate(output, chestplate, material);
        leggings(output, leggings, material);
        boots(output, boots, material);
    }

    protected void helmet(RecipeOutput output, ItemLike helmet, ItemLike material) {
        shaped(RecipeCategory.COMBAT, helmet).define('#', material)
                .pattern("###")
                .pattern("# #")
                .unlockedBy(getHasName(material), has(material))
                .save(output, recipeID(helmet, material));
    }

    protected void helmet(RecipeOutput output, ItemLike helmet, TagKey<Item> material) {
        shaped(RecipeCategory.COMBAT, helmet).define('#', material)
                .pattern("###")
                .pattern("# #")
                .unlockedBy(getHasName(material), has(material))
                .save(output, recipeID(helmet, material));
    }

    protected void chestplate(RecipeOutput output, ItemLike chestplate, ItemLike material) {
        shaped(RecipeCategory.COMBAT, chestplate).define('#', material)
                .pattern("# #")
                .pattern("###")
                .pattern("###")
                .unlockedBy(getHasName(material), has(material))
                .save(output, recipeID(chestplate, material));
    }

    protected void chestplate(RecipeOutput output, ItemLike chestplate, TagKey<Item> material) {
        shaped(RecipeCategory.COMBAT, chestplate).define('#', material)
                .pattern("# #")
                .pattern("###")
                .pattern("###")
                .unlockedBy(getHasName(material), has(material))
                .save(output, recipeID(chestplate, material));
    }

    protected void leggings(RecipeOutput output, ItemLike leggings, ItemLike material) {
        shaped(RecipeCategory.COMBAT, leggings).define('#', material)
                .pattern("###")
                .pattern("# #")
                .pattern("# #")
                .unlockedBy(getHasName(material), has(material))
                .save(output, recipeID(leggings, material));
    }

    protected void leggings(RecipeOutput output, ItemLike leggings, TagKey<Item> material) {
        shaped(RecipeCategory.COMBAT, leggings).define('#', material)
                .pattern("###")
                .pattern("# #")
                .pattern("# #")
                .unlockedBy(getHasName(material), has(material))
                .save(output, recipeID(leggings, material));
    }

    protected void boots(RecipeOutput output, ItemLike boots, ItemLike material) {
        shaped(RecipeCategory.COMBAT, boots).define('#', material)
                .pattern("# #")
                .pattern("# #")
                .unlockedBy(getHasName(material), has(material))
                .save(output, recipeID(boots, material));
    }

    protected void boots(RecipeOutput output, ItemLike boots, TagKey<Item> material) {
        shaped(RecipeCategory.COMBAT, boots).define('#', material)
                .pattern("# #")
                .pattern("# #")
                .unlockedBy(getHasName(material), has(material))
                .save(output, recipeID(boots, material));
    }

    protected void fourConversion(RecipeOutput output, RecipeCategory category, ItemLike to, int count, ItemLike from) {
        shaped(category, to, count).define('#', from)
                .pattern("##")
                .pattern("##")
                .unlockedBy(getHasName(from), has(from))
                .save(output, recipeID(to, from));
    }

    protected void nineBlockStorage(RecipeOutput output, RecipeCategory category, ItemLike unpacked, ItemLike packed) {
        shapeless(category, unpacked, 9).requires(packed).unlockedBy(getHasName(packed), has(packed)).save(output, recipeID(unpacked, packed));
        shaped(category, packed).define('#', unpacked).pattern("###").pattern("###").pattern("###").unlockedBy(getHasName(unpacked), has(unpacked)).save(output, recipeID(packed, unpacked));
    }

    protected void combine(RecipeOutput output, RecipeCategory category, ItemLike result, ItemLike block, ItemLike moss) {
        shapeless(category, result).requires(block).requires(moss).unlockedBy(getHasName(block), has(block)).save(output, recipeID(result, block));
    }

    protected void combine(RecipeOutput output, RecipeCategory category, ItemLike result, TagKey<Item> block, TagKey<Item> moss) {
        shapeless(category, result).requires(block).requires(moss).unlockedBy(getHasName(block), has(block)).save(output, recipeID(result, block));
    }

    @Deprecated
    protected void dying(RecipeOutput output, TagKey<Item> dyedItems, String idPattern, String group) {
        for (var dye : DyeColor.values()) {
            var resultID = locate(idPattern.replace("{color}", dye.getName()));
            var dyeID = ResourceLocation.withDefaultNamespace(dye.getName() + "_dye");
            var result = BuiltInRegistries.ITEM.getOptional(resultID).orElseThrow();
            var dyeItem = BuiltInRegistries.ITEM.getOptional(dyeID).orElseThrow();
            shapeless(RecipeCategory.BUILDING_BLOCKS, result).requires(dyedItems)
                    .requires(dyeItem).group(group)
                    .unlockedBy("has_needed_dye", has(dyeItem))
                    .save(output, locate("dye_" + getItemName(result)));
        }
    }

    protected void dyeing8(RecipeOutput output, RecipeCategory category, ItemLike result, TagKey<Item> source, ItemLike dye, String group) {
        shaped(category, result, 8)
                .define('#', source)
                .define('X', dye)
                .pattern("###")
                .pattern("#X#")
                .pattern("###")
                .group(group)
                .unlockedBy(getHasName(source), has(source))
                .save(output, dyeingRecipeID(result, dye));
    }

    protected void dyeing8(RecipeOutput output, RecipeCategory category, ItemLike result, ItemLike source, ItemLike dye, String group) {
        shaped(category, result, 8)
                .define('#', source)
                .define('X', dye)
                .pattern("###")
                .pattern("#X#")
                .pattern("###")
                .group(group)
                .unlockedBy(getHasName(source), has(source))
                .save(output, dyeingRecipeID(result, dye));
    }

    protected void dyeing1(RecipeOutput output, RecipeCategory category, ItemLike result, ItemLike source, ItemLike dye, String group) {
        shapeless(category, result)
                .requires(source).requires(dye).group(group)
                .unlockedBy(getHasName(source), has(source))
                .save(output, dyeingRecipeID(result, dye));

    }

    protected void dyeing1(RecipeOutput output, RecipeCategory category, ItemLike result, TagKey<Item> source, ItemLike dye, String group) {
        shapeless(category, result)
                .requires(source).requires(dye).group(group)
                .unlockedBy(getHasName(source), has(source))
                .save(output, dyeingRecipeID(result, dye));

    }

    protected void generateSmeltingConversionRecipes(RecipeOutput output, BlockFamily resultFamily, BlockFamily baseFamily, FeatureFlagSet flagSet) {
        resultFamily.getVariants().forEach((variant, result) -> {
            if (result.requiredFeatures().isSubsetOf(flagSet)) {
                var base = baseFamily.get(variant);
                if (base != null && base.requiredFeatures().isSubsetOf(flagSet)) {
                    smelting(output, variant == BlockFamily.Variant.WALL ? RecipeCategory.DECORATIONS : RecipeCategory.BUILDING_BLOCKS, result, base, 0.1F, 200);
                }
            }
        });
    }

    protected void generateStonecuttingConversionRecipes(RecipeOutput output, BlockFamily resultFamily, BlockFamily baseFamily, FeatureFlagSet flagSet) {
        resultFamily.getVariants().forEach((variant, result) -> {
            if (result.requiredFeatures().isSubsetOf(flagSet)) {
                var base = baseFamily.get(variant);
                if (base != null && base.requiredFeatures().isSubsetOf(flagSet)) {
                    stonecutting(output, variant == BlockFamily.Variant.WALL ? RecipeCategory.DECORATIONS : RecipeCategory.BUILDING_BLOCKS, result, base, 1);
                }
            }
        });
    }

    protected void oreSmelting(RecipeOutput output, ItemLike ingot, ItemLike raw) {
        smelting(output, RecipeCategory.MISC, ingot, raw, 0.7f, 200);
        blasting(output, RecipeCategory.MISC, ingot, raw, 0.7f, 100);
    }

    protected void oreSmelting(RecipeOutput output, ItemLike ingot, TagKey<Item> raw) {
        smelting(output, RecipeCategory.MISC, ingot, raw, 0.7f, 200);
        blasting(output, RecipeCategory.MISC, ingot, raw, 0.7f, 100);
    }

    protected void stoneSmelting(RecipeOutput output, ItemLike ingot, TagKey<Item> raw) {
        smelting(output, RecipeCategory.BUILDING_BLOCKS, ingot, raw, 0.1f, 200);
    }

    protected void stoneSmelting(RecipeOutput output, ItemLike ingot, ItemLike raw) {
        smelting(output, RecipeCategory.BUILDING_BLOCKS, ingot, raw, 0.1f, 200);
    }

    protected ShapedRecipeBuilder shaped(RecipeCategory category, ItemLike result) {
        return ShapedRecipeBuilder.shaped(category, result);
    }

    protected ShapedRecipeBuilder shaped(RecipeCategory category, ItemLike result, int count) {
        return ShapedRecipeBuilder.shaped(category, result, count);
    }

    protected ShapelessRecipeBuilder shapeless(RecipeCategory category, ItemLike result) {
        return ShapelessRecipeBuilder.shapeless(category, result);
    }

    protected ShapelessRecipeBuilder shapeless(RecipeCategory category, ItemLike result, int count) {
        return ShapelessRecipeBuilder.shapeless(category, result, count);
    }

    protected void shapeless(RecipeOutput output, RecipeCategory category, ItemLike result, int countR, ItemLike material, int countM) {
        shapeless(category, result, countR).requires(material, countM).unlockedBy(getHasName(material), has(material)).save(output, recipeID(result, material));
    }

    protected void shapeless(RecipeOutput output, RecipeCategory category, ItemLike result, int countR, TagKey<Item> material, int countM) {
        shapeless(category, result, countR).requires(Ingredient.of(material), countM).unlockedBy(getHasName(material), has(material)).save(output, recipeID(result, material));
    }

    protected void stonecutting(RecipeOutput output, RecipeCategory category, ItemLike result, ItemLike material, int count) {
        SingleItemRecipeBuilder.stonecutting(Ingredient.of(material), category, result, count).unlockedBy(getHasName(material), has(material)).save(output, stonecuttingRecipeID(result, material));
    }

    protected void smelting(RecipeOutput output, RecipeCategory category, ItemLike result, ItemLike ingredient, float xp, int time) {
        SimpleCookingRecipeBuilder.smelting(Ingredient.of(ingredient), category, result, xp, time).unlockedBy(getHasName(ingredient), has(ingredient)).save(output, smeltingRecipeID(result, ingredient));
    }

    protected void smelting(RecipeOutput output, RecipeCategory category, ItemLike result, TagKey<Item> ingredient, float xp, int time) {
        SimpleCookingRecipeBuilder.smelting(Ingredient.of(ingredient), category, result, xp, time).unlockedBy(getHasName(ingredient), has(ingredient)).save(output, smeltingRecipeID(result, ingredient));
    }

    protected void blasting(RecipeOutput output, RecipeCategory category, ItemLike result, ItemLike ingredient, float xp, int time) {
        SimpleCookingRecipeBuilder.blasting(Ingredient.of(ingredient), category, result, xp, time).unlockedBy(getHasName(ingredient), has(ingredient)).save(output, blastingRecipeID(result, ingredient));
    }

    protected void blasting(RecipeOutput output, RecipeCategory category, ItemLike result, TagKey<Item> ingredient, float xp, int time) {
        SimpleCookingRecipeBuilder.blasting(Ingredient.of(ingredient), category, result, xp, time).unlockedBy(getHasName(ingredient), has(ingredient)).save(output, blastingRecipeID(result, ingredient));
    }

    protected void smoking(RecipeOutput output, ItemLike result, ItemLike ingredient, float xp, int time) {
        SimpleCookingRecipeBuilder.smoking(Ingredient.of(ingredient), RecipeCategory.FOOD, result, xp, time).unlockedBy(getHasName(ingredient), has(ingredient)).save(output, smokingRecipeID(result, ingredient));
    }

    protected void smoking(RecipeOutput output, ItemLike result, TagKey<Item> ingredient, float xp, int time) {
        SimpleCookingRecipeBuilder.smoking(Ingredient.of(ingredient), RecipeCategory.FOOD, result, xp, time).unlockedBy(getHasName(ingredient), has(ingredient)).save(output, smokingRecipeID(result, ingredient));
    }

    protected ResourceLocation recipeID(ItemLike result, ItemLike ingredient) {
        return prefixedRecipeID(result, ingredient, "");
    }

    protected ResourceLocation recipeID(ItemLike result, TagKey<Item> ingredient) {
        return prefixedRecipeID(result, ingredient, "");
    }

    protected ResourceLocation stonecuttingRecipeID(ItemLike result, ItemLike ingredient) {
        return prefixedRecipeID(result, ingredient, "stonecutting/");
    }

    protected ResourceLocation stonecuttingRecipeID(ItemLike result, TagKey<Item> ingredient) {
        return prefixedRecipeID(result, ingredient, "stonecutting/");
    }

    protected ResourceLocation smeltingRecipeID(ItemLike result, ItemLike ingredient) {
        return prefixedRecipeID(result, ingredient, "smelting/");
    }

    protected ResourceLocation smeltingRecipeID(ItemLike result, TagKey<Item> ingredient) {
        return prefixedRecipeID(result, ingredient, "smelting/");
    }

    protected ResourceLocation blastingRecipeID(ItemLike result, ItemLike ingredient) {
        return prefixedRecipeID(result, ingredient, "blasting/");
    }

    protected ResourceLocation blastingRecipeID(ItemLike result, TagKey<Item> ingredient) {
        return prefixedRecipeID(result, ingredient, "blasting/");
    }

    protected ResourceLocation smokingRecipeID(ItemLike result, ItemLike ingredient) {
        return prefixedRecipeID(result, ingredient, "smoking/");
    }

    protected ResourceLocation smokingRecipeID(ItemLike result, TagKey<Item> ingredient) {
        return prefixedRecipeID(result, ingredient, "smoking/");
    }

    protected ResourceLocation dyeingRecipeID(ItemLike result, ItemLike ingredient) {
        return prefixedRecipeID(result, ingredient, "dyeing/");
    }

    protected ResourceLocation dyeingRecipeID(ItemLike result, TagKey<Item> ingredient) {
        return prefixedRecipeID(result, ingredient, "dyeing/");
    }

    protected ResourceLocation prefixedRecipeID(ItemLike result, ItemLike ingredient, String prefix) {
        final var itemID = getItemName(result);
        var recipeID = locate(prefix + itemID);
        if (knownRecipes.contains(recipeID)) {
            recipeID = locate(prefix + getConversionRecipeName(itemID, ingredient));
            if (knownRecipes.contains(recipeID)) throw new IllegalStateException("duplicate recipe key:" + recipeID);
        }
        return recipeID;
    }

    protected ResourceLocation prefixedRecipeID(ItemLike result, TagKey<Item> ingredient, String prefix) {
        final var itemID = getItemName(result);
        var recipeID = locate(prefix + itemID);
        if (knownRecipes.contains(recipeID)) {
            recipeID = locate(prefix + getConversionRecipeName(itemID, ingredient));
            if (knownRecipes.contains(recipeID)) throw new IllegalStateException("duplicate recipe key:" + recipeID);
        }
        return recipeID;
    }

    protected String getConversionRecipeName(String result, ItemLike ingredient) {
        return result + "_from_" + getItemName(ingredient);
    }

    protected String getConversionRecipeName(String result, TagKey<Item> ingredient) {
        return result + "_from_" + getItemTagName(ingredient);
    }

    protected String getHasName(TagKey<Item> tag) {
        return "has_" + getItemTagName(tag);
    }

    protected String getItemTagName(TagKey<Item> tag) {
        return tag.location().getPath().replace('/', '_');
    }

    protected ResourceLocation locate(String key) {
        if (key.contains(":")) {
            return ResourceLocation.bySeparator(key, ':');
        }
        // explicitly create from consumer provided mod id
        return ResourceLocation.fromNamespaceAndPath(modId, key);
    }

    protected FamilyBuilder family(BlockFamily family) {
        return new FamilyBuilder(family, DEFAULT_FEATURE_FLAG_SET);
    }

    protected FamilyBuilder family(BlockFamily family, FeatureFlagSet featureFlags) {
        return new FamilyBuilder(family, featureFlags);
    }

    protected final class FamilyBuilder {
        private final BlockFamily family;
        private final FeatureFlagSet featureFlags;

        public FamilyBuilder(BlockFamily family, FeatureFlagSet featureFlags) {
            this.family = family;
            this.featureFlags = featureFlags;
        }

        public FamilyBuilder generate(RecipeOutput output) {
            generateRecipes(output, family, featureFlags);
            return this;
        }

        public FamilyBuilder generateStonecuttingConversions(RecipeOutput output, BlockFamily baseFamily) {
            generateStonecuttingConversionRecipes(output, family, baseFamily, featureFlags);
            return this;
        }

        public FamilyBuilder generateSmeltingConversions(RecipeOutput output, BlockFamily baseFamily) {
            generateSmeltingConversionRecipes(output, family, baseFamily, featureFlags);
            return this;
        }
    }
}
