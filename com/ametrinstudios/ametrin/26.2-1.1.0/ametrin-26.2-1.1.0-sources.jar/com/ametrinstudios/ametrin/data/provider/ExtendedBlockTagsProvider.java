package com.ametrinstudios.ametrin.data.provider;

import com.ametrinstudios.ametrin.data.BlockTagProviderRule;
import net.minecraft.core.HolderLookup;
import net.minecraft.data.PackOutput;
import net.minecraft.resources.ResourceKey;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.level.block.*;
import net.neoforged.neoforge.common.data.BlockTagsProvider;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

import java.util.ArrayList;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Stream;

public abstract class ExtendedBlockTagsProvider extends BlockTagsProvider {
    public ArrayList<ResourceKey<Block>> excludedBlocks = new ArrayList<>();
    public ArrayList<BlockTagProviderRule> blockTagProviderRules = new ArrayList<>();

    public ExtendedBlockTagsProvider(PackOutput output, CompletableFuture<HolderLookup.Provider> registries, String modID) {
        super(output, registries, modID);
    }

    protected void runRules(DeferredRegister.Blocks blockRegistry) {
        runRules(blockRegistry.getEntries().stream());
    }

    protected void runRules(Stream<DeferredHolder<Block, ? extends Block>> blocks) {
        blocks.forEach(holder -> {
            final var key = holder.getKey();

            if (excludedBlocks.contains(holder.getKey())) {
                return;
            }

            final var name = key.identifier().getPath();
            final var block = holder.get();

            for (BlockTagProviderRule provider : blockTagProviderRules) {
                provider.generate(holder, name);
            }

            if (block instanceof FlowerPotBlock) {
                tag(BlockTags.FLOWER_POTS).add(key);
            }
            if (block instanceof FireBlock) {
                tag(BlockTags.FIRE).add(key);
            }
            if (block instanceof CampfireBlock) {
                tag(BlockTags.CAMPFIRES).add(key);
            }
            if (block instanceof StandingSignBlock) {
                tag(BlockTags.STANDING_SIGNS).add(key);
            }
            if (block instanceof WallSignBlock) {
                tag(BlockTags.WALL_SIGNS).add(key);
            }
            if (block instanceof CeilingHangingSignBlock) {
                tag(BlockTags.CEILING_HANGING_SIGNS).add(key);
            }
            if (block instanceof WallHangingSignBlock) {
                tag(BlockTags.WALL_HANGING_SIGNS).add(key);
            }
            if (block instanceof CauldronBlock) {
                tag(BlockTags.CAULDRONS).add(key);
            }
            if (block.defaultBlockState().canBeReplaced()) {
                tag(BlockTags.REPLACEABLE).add(key);
            }
        });
    }
}