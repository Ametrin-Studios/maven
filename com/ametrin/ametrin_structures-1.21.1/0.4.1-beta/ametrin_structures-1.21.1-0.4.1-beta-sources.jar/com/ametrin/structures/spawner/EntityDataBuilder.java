package com.ametrin.structures.spawner;

import com.ametrin.structures.util.ASNbt;
import com.ametrin.structures.util.ItemStackTemplate;
import com.mojang.serialization.Codec;
import com.mojang.serialization.DynamicOps;
import com.mojang.serialization.JsonOps;
import net.minecraft.core.Holder;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.FloatTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.NbtOps;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.ComponentSerialization;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.AgeableMob;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.level.ItemLike;
import net.minecraft.world.level.storage.loot.LootTable;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Supplier;

/// An entity's data, for spawners, entity fixtures and passengers.
///
/// Setting anything makes the entity skip its own spawn randomization, like random armor and handedness, the same as vanilla spawners.
/// Entity fixtures keep the randomization when only a [#deathLootTable] or equipment is set.
public final class EntityDataBuilder {
    public static final String DEATH_LOOT_TABLE_KEY = "DeathLootTable";
    /// Where a mob keeps its equipment.
    public static final List<String> EQUIPMENT_KEYS = List.of("ArmorItems", "HandItems", "body_armor_item");
    private static final List<EquipmentSlot> ARMOR_SLOTS = List.of(EquipmentSlot.FEET, EquipmentSlot.LEGS, EquipmentSlot.CHEST, EquipmentSlot.HEAD);
    private static final List<EquipmentSlot> HAND_SLOTS = List.of(EquipmentSlot.MAINHAND, EquipmentSlot.OFFHAND);

    private final EntityType<?> entity;
    private final CompoundTag data = new CompoundTag();
    private final Map<EquipmentSlot, Tag> equipment = new EnumMap<>(EquipmentSlot.class);
    private final Map<EquipmentSlot, ItemStackTemplate> items = new EnumMap<>(EquipmentSlot.class);
    private final Map<EquipmentSlot, Float> dropChances = new EnumMap<>(EquipmentSlot.class);
    private final Map<Holder<Attribute>, Double> attributes = new LinkedHashMap<>();
    private final List<MobEffectInstance> effects = new ArrayList<>();
    private final List<String> tags = new ArrayList<>();
    private final ListTag passengers = new ListTag();

    public EntityDataBuilder(EntityType<?> entity) {
        this.entity = entity;
    }

    public static EntityDataBuilder of(EntityType<?> entity) {
        return new EntityDataBuilder(entity);
    }

    public EntityDataBuilder name(Component name) {
        data.putString("CustomName", ComponentSerialization.CODEC.encodeStart(JsonOps.INSTANCE, name).getOrThrow().toString());
        return this;
    }

    /// Shows the name even when the entity isn't looked at.
    public EntityDataBuilder nameVisible() {
        data.putBoolean("CustomNameVisible", true);
        return this;
    }

    public EntityDataBuilder health(float health) {
        data.putFloat("Health", health);
        return this;
    }

    public EntityDataBuilder maxHealth(double maxHealth) {
        return attribute(Attributes.MAX_HEALTH, maxHealth).health((float) maxHealth);
    }

    public EntityDataBuilder attribute(Holder<Attribute> attribute, double base) {
        attributes.put(attribute, base);
        return this;
    }

    public EntityDataBuilder effect(MobEffectInstance effect) {
        effects.add(effect);
        return this;
    }

    public EntityDataBuilder leftHanded() {
        data.putBoolean("LeftHanded", true);
        return this;
    }

    public EntityDataBuilder baby() {
        data.putInt("Age", AgeableMob.BABY_START_AGE);
        data.putBoolean("IsBaby", true);
        return this;
    }

    public EntityDataBuilder persistent() {
        data.putBoolean("PersistenceRequired", true);
        return this;
    }

    public EntityDataBuilder canPickUpLoot() {
        data.putBoolean("CanPickUpLoot", true);
        return this;
    }

    public EntityDataBuilder noAi() {
        data.putBoolean("NoAI", true);
        return this;
    }

    public EntityDataBuilder silent() {
        data.putBoolean("Silent", true);
        return this;
    }

    public EntityDataBuilder glowing() {
        data.putBoolean("Glowing", true);
        return this;
    }

    public EntityDataBuilder invulnerable() {
        data.putBoolean("Invulnerable", true);
        return this;
    }

    /// A scoreboard tag, for commands.
    public EntityDataBuilder tag(String tag) {
        tags.add(tag);
        return this;
    }

    public EntityDataBuilder equip(EquipmentSlot slot, ItemLike item) {
        return equip(slot, new ItemStackTemplate(item.asItem()));
    }

    /// Stacks that use datapack content, like enchanted ones, need [#equip(EquipmentSlot, ItemStackTemplate, HolderLookup.Provider)], which datagen can't call. Use an equipment loot table there instead.
    public EntityDataBuilder equip(EquipmentSlot slot, ItemStackTemplate stack) {
        return equip(slot, stack, NbtOps.INSTANCE);
    }

    public EntityDataBuilder equip(EquipmentSlot slot, ItemStackTemplate stack, HolderLookup.Provider registries) {
        return equip(slot, stack, registries.createSerializationContext(NbtOps.INSTANCE));
    }

    // An item stack reads the same fields.
    private EntityDataBuilder equip(EquipmentSlot slot, ItemStackTemplate stack, DynamicOps<Tag> ops) {
        equipment.put(slot, ItemStackTemplate.MAP_CODEC.codec().encodeStart(ops, stack).getOrThrow());
        items.put(slot, stack);
        return this;
    }

    public EntityDataBuilder deathLootTable(ResourceKey<LootTable> lootTable) {
        ASNbt.store(data, DEATH_LOOT_TABLE_KEY, ResourceKey.codec(Registries.LOOT_TABLE), lootTable);
        return this;
    }

    /// Default is 0.085. 1 or more always drops undamaged.
    public EntityDataBuilder dropChance(EquipmentSlot slot, float chance) {
        dropChances.put(slot, chance);
        return this;
    }

    public EntityDataBuilder passenger(EntityType<?> passenger) {
        return passenger(new EntityDataBuilder(passenger));
    }

    public EntityDataBuilder passenger(EntityDataBuilder passenger) {
        return passenger(passenger.build());
    }

    public EntityDataBuilder passenger(CompoundTag passenger) {
        passengers.add(passenger);
        return this;
    }

    public EntityType<?> type() {
        return entity;
    }

    public Map<EquipmentSlot, ItemStackTemplate> equipment() {
        return Map.copyOf(items);
    }

    public CompoundTag build() {
        var tag = data.copy();
        tag.putString("id", BuiltInRegistries.ENTITY_TYPE.getKey(entity).toString());
        if (!attributes.isEmpty()) {
            var list = new ListTag();
            attributes.forEach((attribute, base) -> {
                var entry = new CompoundTag();
                entry.putString("id", attribute.unwrapKey().orElseThrow().location().toString());
                entry.putDouble("base", base);
                list.add(entry);
            });
            tag.put("attributes", list);
        }
        if (!effects.isEmpty()) {
            ASNbt.store(tag, "active_effects", MobEffectInstance.CODEC.listOf(), effects);
        }
        if (!tags.isEmpty()) {
            ASNbt.store(tag, "Tags", Codec.STRING.listOf(), tags);
        }
        putEquipment(tag);
        putDropChances(tag);
        if (!passengers.isEmpty()) {
            tag.put("Passengers", passengers.copy());
        }
        return tag;
    }

    // Mobs read each list as a whole, so slots in a list that are left out are empty.
    private void putEquipment(CompoundTag tag) {
        putSlots(tag, "ArmorItems", ARMOR_SLOTS, equipment, CompoundTag::new);
        putSlots(tag, "HandItems", HAND_SLOTS, equipment, CompoundTag::new);
        if (equipment.containsKey(EquipmentSlot.BODY)) {
            tag.put("body_armor_item", equipment.get(EquipmentSlot.BODY).copy());
        }
    }

    // The same for drop chances, so slots in a list that are left out get vanilla's default.
    private void putDropChances(CompoundTag tag) {
        var chances = new EnumMap<EquipmentSlot, Tag>(EquipmentSlot.class);
        dropChances.forEach((slot, chance) -> chances.put(slot, FloatTag.valueOf(chance)));
        putSlots(tag, "ArmorDropChances", ARMOR_SLOTS, chances, () -> FloatTag.valueOf(Mob.DEFAULT_EQUIPMENT_DROP_CHANCE));
        putSlots(tag, "HandDropChances", HAND_SLOTS, chances, () -> FloatTag.valueOf(Mob.DEFAULT_EQUIPMENT_DROP_CHANCE));
        if (dropChances.containsKey(EquipmentSlot.BODY)) {
            tag.putFloat("body_armor_drop_chance", dropChances.get(EquipmentSlot.BODY));
        }
    }

    private static void putSlots(CompoundTag tag, String key, List<EquipmentSlot> slots, Map<EquipmentSlot, Tag> values, Supplier<Tag> missing) {
        if (slots.stream().noneMatch(values::containsKey)) {
            return;
        }
        var list = new ListTag();
        slots.forEach(slot -> list.add(values.containsKey(slot) ? values.get(slot).copy() : missing.get()));
        tag.put(key, list);
    }
}
