package com.ametrin.structures.structure;

import com.ametrin.structures.structure.modular.ModularStructure;
import net.minecraft.core.RegistrySetBuilder;
import net.minecraft.core.registries.Registries;
import net.minecraft.data.worldgen.BootstrapContext;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.levelgen.structure.Structure;
import net.minecraft.world.level.levelgen.structure.StructureSet;
import net.minecraft.world.level.levelgen.structure.pools.StructureTemplatePool;

import java.util.*;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.stream.Stream;

/// ```
/// public static final StructureBootstrap STRUCTURES = new StructureBootstrap(MOD_ID);
///
/// public static final StructureSetKeys TOWER = STRUCTURES.registerSet("tower", set -> set
///         .evenSpreadPlacement(18, 0.6F)
///         .modular(tower -> tower.single("tower").surface()));
/// ```
public final class StructureBootstrap {
    private final String namespace;
    private final List<StructureSetKeys> sets = new ArrayList<>();
    private final Map<ResourceKey<Structure>, Function<BootstrapContext<Structure>, Structure>> structures = new LinkedHashMap<>();
    private final Map<ResourceKey<StructureSet>, Function<BootstrapContext<StructureSet>, StructureSet>> structureSets = new LinkedHashMap<>();

    public StructureBootstrap(String namespace) {
        this.namespace = namespace;
    }

    /// Declares the set `name` and its structures, named `<name>/<suffix>`.
    public StructureSetKeys registerSet(String name, Consumer<StructureSetBuilder> configure) {
        var builder = new StructureSetBuilder(namespace, name);
        configure.accept(builder);
        var declared = builder.declare();
        if (structureSets.containsKey(declared.keys().key())) {
            throw new IllegalStateException("structure set " + name + " is registered twice");
        }
        declared.structures().keySet().forEach(this::checkUnregistered);
        structures.putAll(declared.structures());
        structureSets.put(declared.keys().key(), declared.set());
        sets.add(declared.keys());
        return declared.keys();
    }

    public ResourceKey<Structure> registerModular(String name, Consumer<ModularStructure.Builder> configure) {
        return register(name, StructureBuilder.configured(new ModularStructure.Builder(namespace, name), configure));
    }

    public ResourceKey<Structure> registerStructure(String name, CustomStructureBuilder.Factory factory, Consumer<CustomStructureBuilder> configure) {
        return register(name, StructureBuilder.configured(new CustomStructureBuilder(name, factory), configure));
    }

    private ResourceKey<Structure> register(String name, StructureBuilder<?> structure) {
        structure.validate();
        var key = ResourceKey.create(Registries.STRUCTURE, ResourceLocation.fromNamespaceAndPath(namespace, name));
        checkUnregistered(key);
        structures.put(key, structure::bootstrap);
        return key;
    }

    private void checkUnregistered(ResourceKey<Structure> key) {
        if (structures.containsKey(key)) {
            throw new IllegalStateException("structure " + key.location() + " is registered twice");
        }
    }

    public String namespace() {
        return namespace;
    }

    /// In the order they were registered.
    public List<StructureSetKeys> sets() {
        return Collections.unmodifiableList(sets);
    }

    public Stream<ResourceKey<Structure>> structures() {
        return structures.keySet().stream().sorted();
    }

    public void addTo(RegistrySetBuilder builder) {
        builder.add(Registries.STRUCTURE_SET, context -> structureSets.forEach((key, factory) -> context.register(key, factory.apply(context))))
                .add(Registries.STRUCTURE, context -> structures.forEach((key, factory) -> context.register(key, factory.apply(context))));
    }
}
