package com.ametrin.structures.debug;

import com.ametrin.structures.util.ASLog;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.exceptions.DynamicCommandExceptionType;
import net.minecraft.commands.CommandBuildContext;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.commands.arguments.IdentifierArgument;
import net.minecraft.commands.arguments.ResourceOrTagKeyArgument;
import net.minecraft.commands.arguments.ResourceOrIdArgument;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.ChatFormatting;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.HoverEvent;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.util.Util;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.levelgen.structure.Structure;
import net.minecraft.world.level.storage.loot.LootParams;
import net.minecraft.world.level.storage.loot.LootTable;
import net.minecraft.world.level.storage.loot.parameters.LootContextParamSets;
import net.minecraft.world.level.storage.loot.parameters.LootContextParams;
import net.minecraft.world.phys.Vec3;
import org.jspecify.annotations.Nullable;

import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.function.Function;
import java.util.function.IntFunction;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import static com.ametrin.structures.debug.ChatReport.*;

/// Rolls loot as if the caller opened chests, luck included, and reports how often each item comes up.
///
/// - `/ametrin loot_stats table <loot_table> [samples]`: one chest where the caller stands.
/// - `/ametrin loot_stats structure <structure> [radius] [layouts]`: every chest in the nearest layouts of the structure, see [StructureLoot].
///   For a structure tag, the layouts of all its structures together.
/// - `/ametrin loot_stats template <template> [samples]`: every chest in the template, placed unrotated where the caller stands.
public final class LootStatsCommand {
    public static final class Keys {
        public static final String SUMMARY = "commands.ametrin_structures.loot_stats.summary";
        public static final String STRUCTURE_STARTED = "commands.ametrin_structures.loot_stats.structure_started";
        public static final String FAILED = "commands.ametrin_structures.loot_stats.failed";
        public static final String NO_LAYOUTS = "commands.ametrin_structures.loot_stats.no_layouts";
        public static final String STRUCTURE_SUMMARY = "commands.ametrin_structures.loot_stats.structure_summary";
        public static final String STRUCTURE_MIX = "commands.ametrin_structures.loot_stats.structure_mix";
        public static final String SOURCES = "commands.ametrin_structures.loot_stats.sources";
        public static final String CODE_PIECES = "commands.ametrin_structures.loot_stats.code_pieces";
        public static final String DATA_MARKERS = "commands.ametrin_structures.loot_stats.data_markers";
        public static final String RANGE_CHEST = "commands.ametrin_structures.loot_stats.range_chest";
        public static final String RANGE_STRUCTURE = "commands.ametrin_structures.loot_stats.range_structure";
        public static final String TEMPLATE_SUMMARY = "commands.ametrin_structures.loot_stats.template_summary";
        public static final String RANGE_TEMPLATE = "commands.ametrin_structures.loot_stats.range_template";
        public static final String UNKNOWN_TEMPLATE = "commands.ametrin_structures.loot_stats.unknown_template";

        private Keys() {}
    }

    private static final DynamicCommandExceptionType UNKNOWN_TEMPLATE = new DynamicCommandExceptionType(id -> Component.translatable(Keys.UNKNOWN_TEMPLATE, id));

    private static final int DEFAULT_SAMPLES = 10_000;
    private static final int DEFAULT_TEMPLATE_SAMPLES = 1_000;
    private static final int MAX_SAMPLES = 100_000;
    private static final int DEFAULT_LAYOUTS = 100;
    private static final int MAX_LAYOUTS = 1_000;
    private static final int DEFAULT_RADIUS = 128;
    private static final int MAX_RADIUS = 16_384;
    private LootStatsCommand() {}

    static LiteralArgumentBuilder<CommandSourceStack> lootStats(CommandBuildContext context) {
        return Commands.literal("loot_stats")
                .requires(Commands.hasPermission(Commands.LEVEL_GAMEMASTERS))
                .then(Commands.literal("table")
                        .then(Commands.argument("loot_table", ResourceOrIdArgument.lootTable(context))
                                .executes(command -> table(command, DEFAULT_SAMPLES))
                                .then(Commands.argument("samples", IntegerArgumentType.integer(1, MAX_SAMPLES))
                                        .executes(command -> table(command, IntegerArgumentType.getInteger(command, "samples"))))))
                .then(Commands.literal("structure")
                        .then(Commands.argument("structure", ResourceOrTagKeyArgument.resourceOrTagKey(Registries.STRUCTURE))
                                .executes(command -> structure(command, DEFAULT_RADIUS, DEFAULT_LAYOUTS))
                                .then(Commands.argument("radius", IntegerArgumentType.integer(1, MAX_RADIUS))
                                        .executes(command -> structure(command, IntegerArgumentType.getInteger(command, "radius"), DEFAULT_LAYOUTS))
                                        .then(Commands.argument("layouts", IntegerArgumentType.integer(1, MAX_LAYOUTS))
                                                .executes(command -> structure(command,
                                                        IntegerArgumentType.getInteger(command, "radius"), IntegerArgumentType.getInteger(command, "layouts")))))))
                .then(Commands.literal("template")
                        .then(Commands.argument("template", IdentifierArgument.id())
                                .suggests((command, builder) -> SharedSuggestionProvider.suggestResource(command.getSource().getServer().getStructureManager().listTemplates(), builder))
                                .executes(command -> template(command, DEFAULT_TEMPLATE_SAMPLES))
                                .then(Commands.argument("samples", IntegerArgumentType.integer(1, MAX_SAMPLES))
                                        .executes(command -> template(command, IntegerArgumentType.getInteger(command, "samples"))))))
                .then(ChatReport.more());
    }

    /// @param total       over all samples
    /// @param samplesWith samples that had at least one
    /// @param min         fewest in one sample, 0 if any sample had none
    /// @param max         most in one sample
    record Counts(long total, int samplesWith, int min, int max) {}

    /// @param empty samples without any item
    record Stats(int samples, int empty, Map<Item, Counts> items) {}

    /// Rolls `table` `samples` times. Uses `random` instead of the table's random sequence, which would advance the world's.
    static Stats sample(LootTable table, LootParams params, int samples, RandomSource random) {
        return sample(samples, _ -> table.getRandomItems(params, random));
    }

    /// @param roll the items of one sample
    static Stats sample(int samples, IntFunction<List<ItemStack>> roll) {
        var perSample = new ArrayList<Map<Item, Integer>>(samples);
        for (int sample = 0; sample < samples; sample++) {
            var counts = new HashMap<Item, Integer>();
            for (var stack : roll.apply(sample)) {
                counts.merge(stack.getItem(), stack.getCount(), Integer::sum);
            }
            perSample.add(counts);
        }
        int empty = (int) perSample.stream().filter(Map::isEmpty).count();
        return new Stats(samples, empty, count(perSample));
    }

    /// Sums each key's counts over `samples`, where a sample without the key counts as 0.
    static <K> Map<K, Counts> count(List<Map<K, Integer>> samples) {
        var tallies = new HashMap<K, Tally>();
        samples.forEach(sample -> sample.forEach((key, count) -> tallies.computeIfAbsent(key, _ -> new Tally()).add(count)));
        var counts = new HashMap<K, Counts>();
        tallies.forEach((key, tally) -> counts.put(key, new Counts(tally.total, tally.samplesWith, tally.samplesWith < samples.size() ? 0 : tally.min, tally.max)));
        return counts;
    }

    private static final class Tally {
        long total;
        int samplesWith;
        int min = Integer.MAX_VALUE;
        int max;

        void add(int count) {
            total += count;
            samplesWith++;
            min = Math.min(min, count);
            max = Math.max(max, count);
        }
    }

    private static int table(CommandContext<CommandSourceStack> command, int samples) throws CommandSyntaxException {
        var source = command.getSource();
        var table = ResourceOrIdArgument.getLootTable(command, "loot_table");
        var player = player(source);
        var params = chestParams(source, BlockPos.containing(source.getPosition()), player);
        var stats = sample(table.value(), params, samples, source.getLevel().getRandom().fork());

        var name = table.unwrapKey().map(key -> key.identifier().toString()).orElse("inline");
        var summary = Component.translatable(Keys.SUMMARY, name, samples, format(luck(player)), percent(stats.empty(), samples));
        sendReport(source, summary, List.of(), stats, "chest", Keys.RANGE_CHEST, "");
        return stats.items().size();
    }

    private static int structure(CommandContext<CommandSourceStack> command, int radius, int count) throws CommandSyntaxException {
        var source = command.getSource();
        var level = source.getLevel();
        var structures = ResourceOrTagKeyArgument.getResourceOrTagKey(command, "structure", Registries.STRUCTURE, SpreadCommand.INVALID_STRUCTURE);
        var registry = level.registryAccess().lookupOrThrow(Registries.STRUCTURE);
        boolean exists = structures.unwrap().map(key -> registry.get(key).isPresent(), tag -> registry.get(tag).isPresent());
        if (!exists) {
            throw SpreadCommand.INVALID_STRUCTURE.create(structures.asPrintable());
        }
        var name = structures.asPrintable();
        var random = level.getRandom().fork();
        var center = ChunkPos.containing(BlockPos.containing(source.getPosition()));
        source.sendSuccess(() -> Component.translatable(Keys.STRUCTURE_STARTED, count, name, radius), false);
        // Laying out structures far away can take a while.
        CompletableFuture.supplyAsync(() -> StructureLoot.layouts(level, structures, center, radius, count, random), Util.backgroundExecutor())
                .whenCompleteAsync((layouts, error) -> {
                    if (error != null) {
                        ASLog.error("structure loot stats failed", error);
                        source.sendFailure(Component.translatable(Keys.FAILED, error.toString()));
                    } else if (layouts.layouts().isEmpty()) {
                        source.sendFailure(Component.translatable(Keys.NO_LAYOUTS, name, radius));
                    } else {
                        structureReport(source, structures, name, layouts, random);
                    }
                }, source.getServer());
        return 1;
    }

    private static int template(CommandContext<CommandSourceStack> command, int samples) throws CommandSyntaxException {
        var source = command.getSource();
        var id = IdentifierArgument.getId(command, "template");
        var template = source.getServer().getStructureManager().get(id).orElseThrow(() -> UNKNOWN_TEMPLATE.create(id));
        var collected = StructureLoot.template(source.getLevel(), template, BlockPos.containing(source.getPosition()));
        var random = source.getLevel().getRandom().fork();
        var contents = IntStream.range(0, samples).mapToObj(_ -> collected.draw(random)).toList();
        var luck = format(luck(player(source)));
        contentsReport(source, stats -> Component.translatable(Keys.TEMPLATE_SUMMARY, id.toString(), samples, luck, percent(stats.empty(), samples)),
                List.of(), contents, "template", Keys.RANGE_TEMPLATE, random);
        return 1;
    }

    private static void structureReport(CommandSourceStack source, ResourceOrTagKeyArgument.Result<Structure> structures, String name, StructureLoot.Layouts found, RandomSource random) {
        var layouts = found.layouts();
        var luck = format(luck(player(source)));
        var extraLines = new ArrayList<Component>();
        if (structures.unwrap().right().isPresent()) {
            var mix = layouts.stream()
                    .collect(Collectors.groupingBy(layout -> layout.structure().unwrapKey().map(key -> key.identifier().toString()).orElse("?"), Collectors.counting()))
                    .entrySet().stream()
                    .sorted(Map.Entry.<String, Long>comparingByValue().reversed())
                    .map(entry -> entry.getKey() + " " + entry.getValue())
                    .collect(Collectors.joining(", "));
            extraLines.add(Component.translatable(Keys.STRUCTURE_MIX, mix));
        }
        int samples = layouts.size();
        contentsReport(source, stats -> Component.translatable(Keys.STRUCTURE_SUMMARY, name, samples, found.radius(), luck, percent(stats.empty(), samples)),
                extraLines, layouts.stream().map(StructureLoot.Layout::contents).toList(), "structure", Keys.RANGE_STRUCTURE, random);
    }

    /// Rolls the loot of each sample once and reports the items and loot sources.
    ///
    /// @param per what one sample is, "structure" or "template"
    private static void contentsReport(CommandSourceStack source, Function<Stats, MutableComponent> summary, List<Component> extraLines, List<StructureLoot.Contents> contents, String per, String rangeKey, RandomSource random) {
        var level = source.getLevel();
        var player = player(source);
        var lootTables = level.getServer().reloadableRegistries();
        var stats = sample(contents.size(), sample -> {
            var items = new ArrayList<ItemStack>();
            for (var container : contents.get(sample).containers()) {
                items.addAll(lootTables.getLootTable(container.lootTable()).getRandomItems(chestParams(source, container.pos(), player), random));
            }
            for (var display : contents.get(sample).displays()) {
                items.addAll(display.drops(level, random));
            }
            return items;
        });
        // A display without an equipment table is listed by its entity type.
        var sources = count(contents.stream().map(sample -> {
            var perSource = new HashMap<String, Integer>();
            sample.containers().forEach(container -> perSource.merge(container.lootTable().identifier().toString(), 1, Integer::sum));
            sample.displays().forEach(display -> perSource.merge(
                    display.equipment().map(table -> table.identifier().toString()).orElseGet(() -> BuiltInRegistries.ENTITY_TYPE.getKey(display.type()).toString()),
                    1, Integer::sum));
            return (Map<String, Integer>) perSource;
        }).toList());

        var lines = new ArrayList<>(extraLines);
        var sortedSources = sortedByTotal(sources);
        var sourceBreakdown = breakdown("loot source\tper " + per + "\tshare of " + per + "s", sortedSources, contents.size());
        lines.add(Component.translatable(Keys.SOURCES, sortedSources.size())
                .withStyle(style -> style.withUnderlined(true).withHoverEvent(new HoverEvent.ShowText(sourceBreakdown.hover()))));
        double codePieces = contents.stream().mapToInt(StructureLoot.Contents::codePieces).average().orElse(0);
        if (codePieces > 0) {
            lines.add(Component.translatable(Keys.CODE_PIECES, format(codePieces), per));
        }
        double dataMarkers = contents.stream().mapToInt(StructureLoot.Contents::dataMarkers).average().orElse(0);
        if (dataMarkers > 0) {
            lines.add(Component.translatable(Keys.DATA_MARKERS, format(dataMarkers), per));
        }
        sendReport(source, summary.apply(stats), lines, stats, per, rangeKey, sourceBreakdown.tsv());
    }

    private static @Nullable Player player(CommandSourceStack source) {
        return source.getEntity() instanceof Player player ? player : null;
    }

    private static float luck(@Nullable Player player) {
        return player != null ? player.getLuck() : 0;
    }

    // Like RandomizableContainer#unpackLootTable when a player opens the chest.
    private static LootParams chestParams(CommandSourceStack source, BlockPos chest, @Nullable Player player) {
        var params = new LootParams.Builder(source.getLevel()).withParameter(LootContextParams.ORIGIN, Vec3.atCenterOf(chest));
        if (player != null) {
            params.withLuck(player.getLuck()).withParameter(LootContextParams.THIS_ENTITY, player);
        }
        return params.create(LootContextParamSets.CHEST);
    }

    /// Sends the summary with a copy button, then the rarest items.
    ///
    /// @param per         what one sample is, "chest", "structure" or "template"
    /// @param extraTsv    appended to the copied items, e.g. the loot sources
    private static void sendReport(CommandSourceStack source, MutableComponent summary, List<Component> extraLines, Stats stats, String per, String rangeKey, String extraTsv) {
        var items = sortedByTotal(stats.items()).reversed();
        var tsv = new StringBuilder("item\tper " + per + "\tshare of " + per + "s\tfewest\tmost\n");
        var lines = new ArrayList<Component>();
        for (var entry : items) {
            var id = BuiltInRegistries.ITEM.getKey(entry.getKey()).toString();
            var counts = entry.getValue();
            tsv.append(id).append('\t').append(average(counts, stats.samples())).append('\t').append(percent(counts.samplesWith(), stats.samples()))
                    .append('\t').append(counts.min()).append('\t').append(counts.max()).append('\n');
            var name = entry.getKey().getDefaultInstance().getStyledHoverName();
            var details = Component.empty().append(name)
                    .append(Component.literal("\n" + id).withStyle(ChatFormatting.DARK_GRAY))
                    .append("\n").append(Component.translatable(rangeKey, counts.min(), counts.max()));
            lines.add(ChatReport.line(counts, stats.samples(), name).withStyle(style -> style.withHoverEvent(new HoverEvent.ShowText(details))));
        }
        tsv.append(extraTsv);
        ChatReport.send(source, summary, extraLines, lines, tsv.toString(), "/ametrin loot_stats");
    }
}
