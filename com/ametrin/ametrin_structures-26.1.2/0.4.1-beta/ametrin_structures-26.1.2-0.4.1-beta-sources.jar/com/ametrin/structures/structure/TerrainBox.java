package com.ametrin.structures.structure;

import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;
import com.mojang.datafixers.util.Either;
import com.mojang.serialization.Codec;
import net.minecraft.core.BlockPos;
import net.minecraft.util.StringRepresentable;
import net.minecraft.world.level.levelgen.structure.BoundingBox;
import net.minecraft.world.level.levelgen.structure.TerrainAdjustment;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructureTemplate;
import org.jetbrains.annotations.ApiStatus;

import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

/// The part of a template that terrain adaptation fits the terrain to.
public sealed interface TerrainBox {
    Codec<TerrainBox> CODEC = Codec.either(Automatic.CODEC, BoundingBox.CODEC)
            .xmap(
                    either -> either.map(automatic -> automatic, Local::new),
                    box -> switch (box) {
                        case Automatic automatic -> Either.left(automatic);
                        case Local(BoundingBox local) -> Either.right(local);
                    });

    /// The whole template.
    static TerrainBox template() {
        return Automatic.TEMPLATE;
    }

    /// The blocks at and below ground level
    static TerrainBox footprint() {
        return Automatic.FOOTPRINT;
    }

    /// None, the terrain stays as it is.
    static TerrainBox none() {
        return Automatic.NONE;
    }

    /// In template coordinates, before rotation.
    static TerrainBox of(int minX, int minY, int minZ, int maxX, int maxY, int maxZ) {
        return new Local(new BoundingBox(minX, minY, minZ, maxX, maxY, maxZ));
    }

    /// How a piece of `template` fits the terrain with this box. A local box's bottom is the ground.
    ///
    /// @param groundLevelDelta how far above the bottom of the template the ground lies
    @ApiStatus.Internal
    default TerrainFit fit(TerrainAdjustment adaptation, StructureTemplate template, int groundLevelDelta) {
        return switch (this) {
            case Automatic.NONE -> new TerrainFit(TerrainAdjustment.NONE, Optional.empty(), groundLevelDelta);
            case Automatic automatic -> new TerrainFit(adaptation, automatic.box(template, groundLevelDelta), groundLevelDelta);
            case Local(var box) -> new TerrainFit(adaptation, Optional.of(box), 0);
        };
    }

    enum Automatic implements TerrainBox, StringRepresentable {
        TEMPLATE("template"),
        FOOTPRINT("footprint"),
        NONE("none");

        public static final Codec<Automatic> CODEC = StringRepresentable.fromEnum(Automatic::values);

        // Keyed by the template's first palette. Saving or loading a template replaces its palettes, so a
        // re-saved template gets a new footprint and the old entry is garbage collected.
        private static final LoadingCache<StructureTemplate.Palette, Map<Integer, Optional<BoundingBox>>> FOOTPRINTS =
                CacheBuilder.newBuilder().weakKeys().build(CacheLoader.from(() -> new ConcurrentHashMap<>()));

        private final String name;

        Automatic(String name) {
            this.name = name;
        }

        private Optional<BoundingBox> box(StructureTemplate template, int groundLevelDelta) {
            return this == FOOTPRINT ? footprint(template, groundLevelDelta) : Optional.empty();
        }

        private static Optional<BoundingBox> footprint(StructureTemplate template, int groundLevelDelta) {
            if (template.palettes.isEmpty()) {
                return Optional.empty();
            }
            return FOOTPRINTS.getUnchecked(template.palettes.getFirst())
                    .computeIfAbsent(groundLevelDelta, delta -> computeFootprint(template, delta));
        }

        // A raised template has no blocks below the ground, so its bottom layer counts as ground level.
        private static Optional<BoundingBox> computeFootprint(StructureTemplate template, int groundLevelDelta) {
            var groundLayer = Math.max(groundLevelDelta, 0);
            var grounded = template.palettes.stream()
                    .flatMap(palette -> palette.blocks().stream())
                    .filter(block -> block.pos().getY() <= groundLayer && !block.state().isAir())
                    .map(StructureTemplate.StructureBlockInfo::pos)
                    .toList();
            var height = template.getSize().getY();
            return BoundingBox.encapsulatingPositions(grounded).map(box ->
                    BoundingBox.fromCorners(new BlockPos(box.minX(), 0, box.minZ()), new BlockPos(box.maxX(), height - 1, box.maxZ())));
        }

        @Override
        public String getSerializedName() {
            return name;
        }
    }

    record Local(BoundingBox box) implements TerrainBox {}
}
