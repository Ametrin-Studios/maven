package com.ametrin.structures.structure;

import com.ametrin.structures.structure.filter.PlacementFilter;
import net.minecraft.core.Holder;
import net.minecraft.core.HolderGetter;
import net.minecraft.core.HolderSet;
import net.minecraft.core.registries.Registries;
import net.minecraft.data.worldgen.BootstrapContext;
import net.minecraft.resources.ResourceKey;
import net.minecraft.tags.BiomeTags;
import net.minecraft.tags.TagKey;
import net.minecraft.util.random.WeightedList;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.levelgen.GenerationStep;
import net.minecraft.world.level.levelgen.structure.Structure;
import net.minecraft.world.level.levelgen.structure.StructureSpawnOverride;
import net.minecraft.world.level.levelgen.structure.TerrainAdjustment;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructureProcessor;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructureProcessorList;
import org.jspecify.annotations.Nullable;

import java.util.*;
import java.util.function.Function;

/// Settings shared by every kind of structure in a set
public abstract class StructureEntryBuilder<B extends StructureEntryBuilder<B>> implements ExtendedStructureBuilder<B> {
    protected final String id;

    private Function<HolderGetter<Biome>, HolderSet<Biome>> biomes = lookup -> lookup.getOrThrow(BiomeTags.IS_OVERWORLD);
    private final Map<MobCategory, StructureSpawnOverride> spawnOverrides = new EnumMap<>(MobCategory.class);
    private GenerationStep.Decoration step = GenerationStep.Decoration.SURFACE_STRUCTURES;
    private TerrainAdjustment terrainAdaptation = TerrainAdjustment.NONE;
    private int weight = 1;
    private final List<PlacementFilter> filters = new ArrayList<>();
    private @Nullable Function<HolderGetter<StructureProcessorList>, Holder<StructureProcessorList>> processors;

    protected StructureEntryBuilder(String id) {
        this.id = id;
    }

    protected abstract B self();

    /// Defaults to `#minecraft:is_overworld`.
    public B biomes(TagKey<Biome> tag) {
        return biomes(lookup -> lookup.getOrThrow(tag));
    }

    @SafeVarargs
    public final B biomes(ResourceKey<Biome>... keys) {
        return biomes(lookup -> HolderSet.direct(Arrays.stream(keys).map(lookup::getOrThrow).toList()));
    }

    public B biomes(Function<HolderGetter<Biome>, HolderSet<Biome>> biomes) {
        this.biomes = biomes;
        return self();
    }

    public B spawnOverride(MobCategory category, StructureSpawnOverride override) {
        spawnOverrides.put(category, override);
        return self();
    }

    /// @param categories leave empty for every category
    public B noSpawns(StructureSpawnOverride.BoundingBoxType boundingBox, MobCategory... categories) {
        for (var category : categories.length == 0 ? MobCategory.values() : categories) {
            spawnOverride(category, new StructureSpawnOverride(boundingBox, WeightedList.of()));
        }
        return self();
    }

    /// Defaults to [GenerationStep.Decoration#SURFACE_STRUCTURES].
    public B step(GenerationStep.Decoration step) {
        this.step = step;
        return self();
    }

    public B terrainAdaptation(TerrainAdjustment terrainAdaptation) {
        this.terrainAdaptation = terrainAdaptation;
        return self();
    }

    /// Relative chance to be tried first among the set's structures. Defaults to 1.
    public B weight(int weight) {
        this.weight = weight;
        return self();
    }

    /// Checked in order once the structure has a start position. Only an [ExtendedStructure] runs them.
    @Override
    public B filter(PlacementFilter filter) {
        filters.add(filter);
        return self();
    }

    /// For [ExtendedTemplateStructurePiece]s without processors of their own, see [InlineFromStructureProcessor].
    public B processors(ResourceKey<StructureProcessorList> processors) {
        this.processors = lookup -> lookup.getOrThrow(processors);
        return self();
    }

    /// For [ExtendedTemplateStructurePiece]s without processors of their own, see [InlineFromStructureProcessor].
    public B processors(Holder<StructureProcessorList> processors) {
        this.processors = _ -> processors;
        return self();
    }

    /// Stored inline, also in every piece that runs them.
    public B processors(List<StructureProcessor> processors) {
        return processors(Holder.direct(new StructureProcessorList(processors)));
    }

    int weight() {
        return weight;
    }

    /// Whether filters or processors were set, which only an [ExtendedStructure] takes.
    protected boolean hasExtendedSettings() {
        return !filters.isEmpty() || processors != null;
    }

    protected void validate() {
        if (weight < 1) {
            throw fail("weight " + weight + " must be at least 1");
        }
    }

    /// Validates and creates the structure, for use outside a [StructureBootstrap].
    public Structure build(BootstrapContext<Structure> context) {
        validate();
        return bootstrap(context);
    }

    protected abstract Structure create(Structure.StructureSettings settings, ExtendedStructureSettings extendedSettings, BootstrapContext<Structure> context);

    protected IllegalStateException fail(String message) {
        return new IllegalStateException("structure " + id + ": " + message);
    }

    protected IllegalStateException fail(String message, Throwable cause) {
        return new IllegalStateException("structure " + id + ": " + message, cause);
    }

    Structure bootstrap(BootstrapContext<Structure> context) {
        var settings = new Structure.StructureSettings(biomes.apply(context.lookup(Registries.BIOME)), Map.copyOf(spawnOverrides), step, terrainAdaptation);
        var resolvedProcessors = processors == null
                ? Optional.<Holder<StructureProcessorList>>empty()
                : Optional.of(processors.apply(context.lookup(Registries.PROCESSOR_LIST)));
        return create(settings, new ExtendedStructureSettings(filters, resolvedProcessors), context);
    }
}
